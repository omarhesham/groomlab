GroomLab press kit
==================

The GroomLab logo, for articles, videos, tutorials and tools that work with GroomLab.
More at https://getgroomlab.com/press. Questions: support@getgroomlab.com.

Writing the name
----------------
Write it GroomLab: one word, capital G and capital L, in running text, headlines and titles.

  Do:     GroomLab
  Don't:  Groom Lab, Groomlab, groomLab, GROOMLAB, Groom-Lab, GL

- Possessive: GroomLab's.
- Lowercase "groomlab" only where a system needs it: URLs, package and file names, handles
  (getgroomlab.com, github.com/thekesslereffect/groomlab).
- Product names: GroomLab for Maya, GroomLab for Blender, the GroomLab app.

Using the logo
--------------
- Use the files as they are. Don't recolor them beyond the versions here, stretch or squash them,
  add effects (shadows, outlines, gradients), or rearrange, crop or redraw the mark and the name.
- Keep clear space around the logo: at least half the mark's height on every side.
- Color versions on white or light backgrounds; the color-on-dark lockup or the white versions on dark
  backgrounds and photos; black where only one dark color prints.
- When you mention GroomLab, link to https://getgroomlab.com.
- Describe your work as "works with GroomLab" or "Hair from GroomLab". Don't present it as official,
  as a partnership, or as endorsed by GroomLab.

Files
-----
groomlab-mark-*        the mark (three strands), square
groomlab-wordmark-*    the name
groomlab-lockup-*      the mark and the name together (the main logo)
  -color               brand colors, name in ink, for light backgrounds
  -color-on-dark       (lockup only) brand colors, name in white, for dark backgrounds
  -black, -white       one color
Each as .svg (vector, any size) and .png 512 and 2048 px wide, transparent.

Colors
------
Red     #FF4D4F
Yellow  #FFC53D
Blue    #2F7BF6
Ink     #1D1D1F  (the name on light backgrounds)
Night   #1C1D21  (dark backgrounds)

Trademarks
----------
GroomLab's source code is open source under the Apache License 2.0, which doesn't grant rights to
the GroomLab name or logo (section 6). GroomLab and the GroomLab logo are trademarks of
Nick Rutlinh; these files may be used to refer to GroomLab as described above.
